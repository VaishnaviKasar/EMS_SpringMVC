package a.b.c.dao;

import java.util.List;
import a.b.c.model.Employee;

public interface EmployeeDAO {

    void save(Employee emp);
    List<Employee> findAll();
    Employee findById(int id);
    void update(Employee emp);
    void delete(int id);
}
