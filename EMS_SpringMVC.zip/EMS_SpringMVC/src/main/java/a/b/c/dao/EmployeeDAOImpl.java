package a.b.c.dao;

import java.sql.*;
import java.util.*;
import org.springframework.stereotype.Repository;
import a.b.c.model.Employee;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO {

    private Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/ems_db?useSSL=false&serverTimezone=UTC",
            "root",
            "Ganesh@13"
        );
    }

    
    public void save(Employee emp) {
        try (Connection con = getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO employee(name,email,department,salary,date_of_joining) VALUES (?,?,?,?,?)"
            );
            ps.setString(1, emp.getName());
            ps.setString(2, emp.getEmail());
            ps.setString(3, emp.getDepartment());
            ps.setDouble(4, emp.getSalary());
            ps.setDate(5, emp.getDateOfJoining());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

  
    public List<Employee> findAll() {
        List<Employee> list = new ArrayList<>();
        try (Connection con = getConnection()) {
            ResultSet rs = con.createStatement()
                .executeQuery("SELECT * FROM employee");
            while (rs.next()) {
                Employee e = new Employee();
                e.setId(rs.getInt("id"));
                e.setName(rs.getString("name"));
                e.setEmail(rs.getString("email"));
                e.setDepartment(rs.getString("department"));
                e.setSalary(rs.getDouble("salary"));
                e.setDateOfJoining(rs.getDate("date_of_joining"));
                list.add(e);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

   
    public Employee findById(int id) {
        Employee e = null;
        try (Connection con = getConnection()) {
            PreparedStatement ps =
                con.prepareStatement("SELECT * FROM employee WHERE id=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                e = new Employee();
                e.setId(rs.getInt("id"));
                e.setName(rs.getString("name"));
                e.setEmail(rs.getString("email"));
                e.setDepartment(rs.getString("department"));
                e.setSalary(rs.getDouble("salary"));
                e.setDateOfJoining(rs.getDate("date_of_joining"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return e;
    }

   
    public void update(Employee emp) {
        try (Connection con = getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                "UPDATE employee SET name=?, email=?, department=?, salary=?, date_of_joining=? WHERE id=?"
            );
            ps.setString(1, emp.getName());
            ps.setString(2, emp.getEmail());
            ps.setString(3, emp.getDepartment());
            ps.setDouble(4, emp.getSalary());
            ps.setDate(5, emp.getDateOfJoining());
            ps.setInt(6, emp.getId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    public void delete(int id) {
        try (Connection con = getConnection()) {
            PreparedStatement ps =
                con.prepareStatement("DELETE FROM employee WHERE id=?");
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
