package a.b.c.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import a.b.c.dao.EmployeeDAO;
import a.b.c.model.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeDAO dao;

    public void addEmployee(Employee emp) {
        dao.save(emp);
    }

    public List<Employee> getEmployees() {
        return dao.findAll();
    }

    public Employee getById(int id) {
        return dao.findById(id);
    }

    public void updateEmployee(Employee emp) {
        dao.update(emp);
    }

    public void deleteEmployee(int id) {
        dao.delete(id);
    }
}
