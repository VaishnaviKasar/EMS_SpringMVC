package a.b.c.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import a.b.c.model.Employee;
import a.b.c.service.EmployeeService;

@Controller
public class EmployeeController {

    @Autowired
    private EmployeeService service;

    // HOME → ADD FORM
    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("employee", new Employee());
        return "addEmployee";
    }

    // CREATE
    @PostMapping("/save")
    public String save(@ModelAttribute Employee emp) {
        service.addEmployee(emp);
        return "redirect:/list";
    }

    // READ
    @GetMapping("/list")
    public String list(Model model) {
        model.addAttribute("employees", service.getEmployees());
        return "listEmployee";
    }

    // EDIT FORM
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") int id, Model model) {
        model.addAttribute("employee", service.getById(id));
        return "editEmployee";
    }

    // UPDATE
    @PostMapping("/update")
    public String update(@ModelAttribute Employee emp) {
        service.updateEmployee(emp);
        return "redirect:/list";
    }

    // DELETE
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable("id") int id) {
        service.deleteEmployee(id);
        return "redirect:/list";
    }
}
