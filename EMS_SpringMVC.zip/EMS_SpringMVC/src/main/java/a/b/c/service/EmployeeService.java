package a.b.c.service;

import java.util.List;
import a.b.c.model.Employee;

public interface EmployeeService {
    void addEmployee(Employee emp);
    List<Employee> getEmployees();
    Employee getById(int id);
    void updateEmployee(Employee emp);
    void deleteEmployee(int id);
}
