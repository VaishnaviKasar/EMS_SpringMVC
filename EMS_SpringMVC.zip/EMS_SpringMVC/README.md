# Employee Management System (Spring MVC)

## Project Description
Employee Management System is a MVC based web application developed using
Spring MVC, JSP, JDBC and MySQL. The application performs CRUD operations
on employee records.

---

## Technologies Used
- Java (JDK 17+)
- Spring MVC
- JSP & JSTL
- JDBC
- MySQL
- Apache Tomcat 10
- Maven

---

## Project Architecture (MVC)
- Model: Employee (Entity), DAO, Service
- View: JSP pages (HTML + CSS)
- Controller: Spring MVC Controller

---

## Features
- Add new employee
- View employee list
- Update employee details
- Delete employee
- Proper page navigation

---

## Database Configuration

### Create Database
```sql
CREATE DATABASE ems_db;
USE ems_db;
